<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:73:"F:\PersonalWorks\boke\public/../application/index\view\message\index.html";i:1494763196;s:66:"F:\PersonalWorks\boke\public/../application/index\view\layout.html";i:1494765363;s:73:"F:\PersonalWorks\boke\public/../application/index\view\public\header.html";i:1494730816;s:70:"F:\PersonalWorks\boke\public/../application/index\view\public\nav.html";i:1494767980;s:73:"F:\PersonalWorks\boke\public/../application/index\view\public\footer.html";i:1494762008;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
<script type="text/javascript" src="/static/layui/layui.js"></script>
<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<style type="text/css">
		.layui-nav{z-index: 99999;}
		.boke-wrap{max-width: 1100px;margin:0 auto;overflow: hidden;zoom: 1;margin-top: 10px;}
		.layui-main{height: 1200px;background-color: #ddd;}
		footer{width: 100%;height: 48px;background-color: #393D49;padding-top: 20px;}
		footer p{text-align: center;color: #fff;padding: 2px;}
	</style>
</head>
<body>
<style type="text/css">
	header{background-color: #393D49;height: 60px;width: 100%;}
	.logo{position: absolute;color: #fff;top: 0px;z-index: 99999999;font-size: 18px;height: 60px;line-height: 60px;left: 0%;}
	.layui-nav{padding-left: 12%;border-radius: 0px;}
	.fa-list{font-size: 18px;color: #fff;height: 60px;line-height: 60px;margin-left:20px;display: none;}

	@media screen and (max-width: 680px) {
	    .layui-nav-tree{display: none;padding-left:0px;width: 100%;}
	    .layui-nav{display: none;}
	    .logo{left: 50%;margin-left: -50px;}
	    .fa-list{display: block;}
	}
	@media screen and (min-width: 680px) and (max-width: 1180px) {
	    .layui-nav{padding-left: 19%;display: block;}
	    .layui-nav-tree{display: none;}
	    .logo{left: 3%;}
	}
	@media screen and (min-width: 1180px) {
	    .layui-nav{padding-left: 13%;display: block;}
	    .layui-nav-tree{display: none;}
	    .logo{left: 3%;}
	}
</style>
<header>
	<?php $menu = (new app\admin\model\MMenu)->getTreeArray();
	?>
	<i class="fa fa-list" onclick="showNav()"></i>
	<ul class="layui-nav layui-nav-tree">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="layui-nav-item">
				<?php if(!empty($vo['child'])): ?>
					<a href="javascript:;"><?php echo $vo['name']; ?></a>
					<dl class="layui-nav-child">
					<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<dd><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a></dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
					</dl>
				<?php else: ?>
					<a href="<?php echo $vo['url']; ?>"><?php echo $vo['name']; ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>

	<div class="logo">
		FUYUN-博客
	</div>
	<ul class="layui-nav">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="layui-nav-item">
				<?php if(!empty($vo['child'])): ?>
					<a href="javascript:;"><?php echo $vo['name']; ?></a>
					<dl class="layui-nav-child">
					<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<dd><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a></dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
					</dl>
				<?php else: ?>
					<a href="<?php echo $vo['url']; ?>"><?php echo $vo['name']; ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>
 
<script>
//注意：导航 依赖 element 模块，否则无法进行功能性操作
layui.use('element', function(){});

function showNav(){
	$(".layui-nav-tree").toggle();
}
</script>
</header>

<style type="text/css">
	.message-index{max-width: 800px;}
	.comment-box{height: 500px;overflow: hidden;position: relative;}
	.comment-box .bg{position: absolute;width: 100%;height: 100%;top: 0px;left: 0px;}
	.comment-box .content{height: 500px;width: 1000px;position: relative;}
	.comment-box p{position: absolute;z-index: 9999;}
	.message-box{background-color: #fff;padding: 20px;}
	.nickname{width: 30%;}
	.layui-input-block{margin-left: 0px;}
	.swiper-container{height: 500px;z-index: -99;}
</style>
<div class="boke-wrap message-index">
	<div id="comment-box" class="comment-box">
		<div class="content">
			<p v-for="p in list_p" :style="{left: p.left+'px',top: p.top + 'px',color: p.color,fontSize:p.fontSize+'px' }">{{p.title}}</p>
		</div>
		<div class="bg">
			<div class="swiper-container">
			    <div class="swiper-wrapper">
			        <div class="swiper-slide" style="background-image: url(http://wpicture.oss-cn-shanghai.aliyuncs.com/boke/images/comment_bg_1.jpg);background-size: 100%100%;"></div>
			        <div class="swiper-slide" style="background-image: url(http://wpicture.oss-cn-shanghai.aliyuncs.com/boke/images/comment_bg_2.jpg);background-size: 100%100%;"></div>
			        <div class="swiper-slide" style="background-image: url(http://wpicture.oss-cn-shanghai.aliyuncs.com/boke/images/comment_bg_3.jpg);background-size: 100%100%;"></div>
			        <div class="swiper-slide" style="background-image: url(http://wpicture.oss-cn-shanghai.aliyuncs.com/boke/images/comment_bg_4.jpg);background-size: 100%100%;"></div>
			    </div>
		    </div>
		</div>
	</div>
	<div class="message-box">
		<div class="layui-form-item layui-form-text">
			<!-- <label class="layui-form-label">留言</label> -->
			<div class="layui-input-block">
				<textarea name="desc" placeholder="请输入留言" class="layui-textarea"></textarea>
			</div>
		</div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
			</div>
		</div>
	</div>
	<script type="text/javascript" src="http://cdn.bootcss.com/vue/2.3.0/vue.js"></script>
	<link rel="stylesheet" href="/static/swiper/swiper.min.css">
	<script type="text/javascript" src="/static/swiper/swiper.min.js"></script>

	<script type="text/javascript">
		var width = $(".comment-box").width();
		var height = $(".comment-box").height()-30;
		vm = new Vue({
			el:"#comment-box",
			data:{
				default_color:['#f44336','#e91e63','#9c27b0','#673ab7','#2196f3','#03a9f4','#00bcd4','#009688','#8bc34a','#ffeb3b','#ffc107','#ff9800','#ff5722','#795548','#9e9e9e'],
				default_p:['真的不错！','测试！','测试！','测试！','测试！'],
				list_p:[],
			},
			created: function(){
				for (var i = this.default_p.length; i > 0; i--) {
					var left = Math.ceil(Math.random()*width);
					var top = Math.ceil(Math.random()*height);
					var fontSize = Math.ceil(Math.random()*9)+18;
					var stup = Math.ceil(Math.random()*9)+1;
					var color = this.default_color[Math.floor(Math.random()*(this.default_color.length-1))];
					this.list_p.push({ 'title':this.default_p[i],'top':top,'left':width,'fontSize':fontSize,'color':color,stup:stup});
				}
			}
		});

		window.setInterval(function(){
			$(vm.list_p).each(function(index, value){
				vm.list_p[index].left -= vm.list_p[index].stup;
				if(vm.list_p[index].left < 0 ){
					vm.list_p.splice(index,1);
					vm.list_p.push(random_p());

				}
			});
		},60);

		function random_p(title = ''){
			var left = Math.ceil(Math.random()*width);
			var top = Math.ceil(Math.random()*height);
			var fontSize = Math.ceil(Math.random()*9)+18;
			var stup = Math.ceil(Math.random()*9)+1;
			var color = vm.default_color[Math.floor(Math.random()*vm.default_color.length-1)];
			if(title == ''){
				title = vm.default_p[Math.floor(Math.random()*vm.default_p.length-1)];
			}
			
			return { 'title':title,'top':top,'left':width,'fontSize':fontSize,'color':color,stup:stup};
		}


		$(".layui-btn").click(function(){
			var content = $(".layui-textarea").val();
		    $.ajax({
		    	type:'post',
		    	url:"<?php echo Url('Portal/Message/send'); ?>",
		    	data:{'content': content},
		    	dataType:'json',
		    	success:function(result){
		        	if(result.status == 200){
		        		layer.msg('留言成功！');
		        		vm.list_p.push(random_p(content));
		        	}
		    }});
		});


		var mySwiper = new Swiper('.swiper-container', {
			autoplay: 5000,//可选选项，自动滑动
			effect : 'fade',
		})
	</script>
</div>


<footer>
	<p>fuyun博客 email:1440030538@qq.com</p>
	<p>浙ICP备17001674号-1</p>
</footer>

<script type="text/javascript">
	document_height = $(document).height()-138;
	$(".boke-wrap").css('min-height',document_height+"px");
	// console.log(document_height);
</script>
</body>
</html>