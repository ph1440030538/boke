<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:69:"F:\PersonalWorks\boke\public/../application/admin\view\boke\edit.html";i:1494461177;s:66:"F:\PersonalWorks\boke\public/../application/admin\view\layout.html";i:1493954682;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_header.html";i:1494253897;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
	</head>
<body>

 <form class="layui-form" method="post">
	<div class="layui-form-item">
		<label class="layui-form-label">标题</label>
		<div class="layui-input-block">
			<input type="text" name="title" placeholder="请输入标题" class="layui-input" value="<?php echo $model['title']; ?>" >
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">关键字</label>
		<div class="layui-input-block">
			<input type="text" name="keywords" placeholder="请输入关键字" class="layui-input" value="<?php echo $model['keywords']; ?>">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">描述</label>
		<div class="layui-input-block">
			<input type="text" name="describe" placeholder="请输入描述" class="layui-input" value="<?php echo $model['describe']; ?>">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">内容</label>
		<div class="layui-input-block">
			<input type="text" name="content" placeholder="请输入内容" class="layui-input" value="<?php echo $model['content']; ?>">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">文章来源</label>
		<div class="layui-input-block">
			<input type="text" name="source" placeholder="请输入文章来源" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label"></label>
		<div class="layui-input-block">
			<input type="text" name="create_time" placeholder="请输入" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label"></label>
		<div class="layui-input-block">
			<input type="text" name="update_time" placeholder="请输入" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label"></label>
		<div class="layui-input-block">
			<input type="text" name="status" placeholder="请输入" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label"></label>
		<div class="layui-input-block">
			<input type="text" name="article_tpl" placeholder="请输入" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-input-block">
			<input type="hidden" name="id" value="<?php echo $model['id']; ?>">
			<button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>

<script type="text/javascript">
	layui.use('form', function(){
  		var form = layui.form();

		form.on('submit(*)', function(data){
			return true;
		});

	})
</script>

		
	</body>
</html>