<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:71:"F:\PersonalWorks\boke\public/../application/index\view\tools\index.html";i:1494765365;s:66:"F:\PersonalWorks\boke\public/../application/index\view\layout.html";i:1494765363;s:73:"F:\PersonalWorks\boke\public/../application/index\view\public\header.html";i:1494730816;s:70:"F:\PersonalWorks\boke\public/../application/index\view\public\nav.html";i:1494767980;s:73:"F:\PersonalWorks\boke\public/../application/index\view\public\footer.html";i:1494762008;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
<script type="text/javascript" src="/static/layui/layui.js"></script>
<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<style type="text/css">
		.layui-nav{z-index: 99999;}
		.boke-wrap{max-width: 1100px;margin:0 auto;overflow: hidden;zoom: 1;margin-top: 10px;}
		.layui-main{height: 1200px;background-color: #ddd;}
		footer{width: 100%;height: 48px;background-color: #393D49;padding-top: 20px;}
		footer p{text-align: center;color: #fff;padding: 2px;}
	</style>
</head>
<body>
<style type="text/css">
	header{background-color: #393D49;height: 60px;width: 100%;}
	.logo{position: absolute;color: #fff;top: 0px;z-index: 99999999;font-size: 18px;height: 60px;line-height: 60px;left: 0%;}
	.layui-nav{padding-left: 12%;border-radius: 0px;}
	.fa-list{font-size: 18px;color: #fff;height: 60px;line-height: 60px;margin-left:20px;display: none;}

	@media screen and (max-width: 680px) {
	    .layui-nav-tree{display: none;padding-left:0px;width: 100%;}
	    .layui-nav{display: none;}
	    .logo{left: 50%;margin-left: -50px;}
	    .fa-list{display: block;}
	}
	@media screen and (min-width: 680px) and (max-width: 1180px) {
	    .layui-nav{padding-left: 19%;display: block;}
	    .layui-nav-tree{display: none;}
	    .logo{left: 3%;}
	}
	@media screen and (min-width: 1180px) {
	    .layui-nav{padding-left: 13%;display: block;}
	    .layui-nav-tree{display: none;}
	    .logo{left: 3%;}
	}
</style>
<header>
	<?php $menu = (new app\admin\model\MMenu)->getTreeArray();
	?>
	<i class="fa fa-list" onclick="showNav()"></i>
	<ul class="layui-nav layui-nav-tree">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="layui-nav-item">
				<?php if(!empty($vo['child'])): ?>
					<a href="javascript:;"><?php echo $vo['name']; ?></a>
					<dl class="layui-nav-child">
					<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<dd><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a></dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
					</dl>
				<?php else: ?>
					<a href="<?php echo $vo['url']; ?>"><?php echo $vo['name']; ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>

	<div class="logo">
		FUYUN-博客
	</div>
	<ul class="layui-nav">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="layui-nav-item">
				<?php if(!empty($vo['child'])): ?>
					<a href="javascript:;"><?php echo $vo['name']; ?></a>
					<dl class="layui-nav-child">
					<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<dd><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a></dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
					</dl>
				<?php else: ?>
					<a href="<?php echo $vo['url']; ?>"><?php echo $vo['name']; ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>
 
<script>
//注意：导航 依赖 element 模块，否则无法进行功能性操作
layui.use('element', function(){});

function showNav(){
	$(".layui-nav-tree").toggle();
}
</script>
</header>

	<style>
		body{background-color: #efefef;}
		.strtotime-box{background-color: #fff;padding: 8px;}
		.tools-title{font-size: 18px;padding-left: 13px;}
		.tools-1{padding: 3px;}
		.tools-1 input{border: 1px solid #ddd;height: 38px;line-height: 32px;padding: 2px;padding-left: 5px;border-radius: 1px;margin: 0px 5px;}
		.strtotime-box label{display: inline-block;color: #666;font-size: 13px;padding-left: 12px;font-weight: 600;}
		.tools-1 button{background: #efefef;}
		
		.json-box{background-color: #fff;height: 280px;margin-top: 10px;padding: 5px;}
		.json-box textarea{height: 200px;}
		.json-box button{margin-top: 10px;}
	</style>
<div class="boke-wrap tools-index">
	<div class="strtotime-box">
		<p class="tools-title">时间戳转换</p>
		<label>当前Unix时间戳(支持10位和13位时间戳)</label>
		<div class="tools-1">
			<input class="date-1" type="text" placeholder="当前Unix时间戳" value="<?=time()?>" />
			<button class="layui-btn layui-btn-primary" lay-submit lay-filter="formDemo" onclick="tostrtotime()">转换</button>
			<input class="strtotime-1" type="text" name="" />
		</div>
		<label>北京时间转Unix</label>
		<div class="tools-1">
			<input class="date-2" type="text" style="width: 230px;" placeholder="时间格式：2017/01/01 12:30:00" value="2017/01/01 12:30:00" />
			<button class="layui-btn layui-btn-primary" lay-submit lay-filter="formDemo"  onclick="todate()">转换为Unix时间</button>
			<input class="strtotime-2" type="text" name="" />
		</div>
	</div>
	<div class="json-box">
		<p class="tools-title">JSON格式化及高亮</p>
		<textarea name="desc" placeholder='{"name":"\u5F20\u4E09","addtime":"2014-01-01","username":"abc","id":5}' class="layui-textarea json_txt"></textarea>
		<button class="layui-btn layui-btn-primary" lay-submit lay-filter="formDemo"  onclick="tojson()">转换</button>
	</div>
</div>

<script type="text/javascript">
	/*时间戳转化时间*/
	function tostrtotime(){
		var unixtime = $(".date-1").val();
		if(unixtime.length == 10){
			var timestr = new Date(parseInt(unixtime) * 1000);
			var datetime = timestr.toLocaleString().replace(/年|月/g,"-").replace(/日/g," ").replace(/-/g,"\/");
			$(".strtotime-1").val( datetime );
		}else if(unixtime.length == 13){
			var timestr = new Date(parseInt(unixtime));
			var datetime = timestr.toLocaleString().replace(/年|月/g,"-").replace(/日/g," ").replace(/-/g,"\/");
			$(".strtotime-1").val( datetime );
		}else{
			$(".strtotime-1").val('');
		}
	}

	/*时间转换时间戳*/
	function todate(){
		var stringTime = $(".date-2").val();
		var timestamp2 = Date.parse(new Date(stringTime));
		timestamp2 = timestamp2 / 1000;
		$(".strtotime-2").val(timestamp2);
	}

	/*json美化*/
	function tojson(){
		var json_txt = $(".json_txt").val();
		json_txt = JSON.parse(json_txt);
		$(".json_txt").val( JSON.stringify(json_txt,null,4) );

	}
</script>


<footer>
	<p>fuyun博客 email:1440030538@qq.com</p>
	<p>浙ICP备17001674号-1</p>
</footer>

<script type="text/javascript">
	document_height = $(document).height()-138;
	$(".boke-wrap").css('min-height',document_height+"px");
	// console.log(document_height);
</script>
</body>
</html>