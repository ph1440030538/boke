<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:72:"F:\PersonalWorks\boke\public/../application/admin\view\boketest\add.html";i:1494778508;s:66:"F:\PersonalWorks\boke\public/../application/admin\view\layout.html";i:1494768442;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_header.html";i:1494647407;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .boke-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		    .boke-wrap .boke-search{padding: 10px 20px;background-color: #efefef;}
		    .boke-wrap .boke-search .layui-inline{margin-right: 18px;}
			.boke-wrap .boke-table tfoot{background-color: #efefef;}
		</style>
	</head>
<body>

 <style type="text/css">
	.layui-form{padding: 10px;overflow: hidden;zoom: 1;}
	.left-box{width: 68%;float: left;padding-right: 2%;}
	.right-box{width: 30%;float: left;
		margin-left: -2%;padding-left: 2%;}
	.right-box .layui-form-item{padding-right: 10px;}
	#LAY_demo_upload{max-width: 100%;
		max-height: 160px;}
</style>
<div class="boke-wrap">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li><a href='<?php echo Url("index"); ?>' >测试列表</a></li>
            <li class="layui-this"><a href='javascript:;' >添加测试</a></li>
        </ul>
    </div>

	<form class="layui-form" method="post" action="<?php echo Url('add'); ?>" skipurl="<?php echo Url('index'); ?>">
		<div class="left-box">
            
			<div class="layui-form-item">
				<label class="layui-form-label">名字</label>
				<div class="layui-input-inline">
					<input type="text" name="name" placeholder="请输入名字" class="layui-input">
				</div>
			</div>

			<div class="layui-form-item">
				<label class="layui-form-label">关键字</label>
				<div class="layui-input-inline">
					<input type="text" name="keyword" placeholder="请输入关键字" class="layui-input">
				</div>
			</div>

			<div class="layui-form-item">
				<label class="layui-form-label">图片</label>
				<div class="layui-input-block">
					<div class="site-demo-upload">
						<img id="LAY_demo_upload" src="">
						<div class="site-demo-upbar">
							<input type="file" name="image" lay-type="IMA" class="layui-upload-file">
						</div>
					</div>
					<input type="hidden" id="image" name="image" >
				</div>
				<script type="text/javascript">
					layui.use(["upload"],function(){
						layui.upload({
							url: "<?php echo Url("upload/image"); ?>"
							,success: function(res){
								$("#LAY_demo_upload").attr("src",res.data.src);
								$("#image").val(res.data.src);
							}
						});  
					});
				</script>
			</div>

            <div class="layui-form-item">
            	<label class="layui-form-label">类型</label>
                <div class="layui-input-inline">
                    <select name="image">
                        <option value='1'>input</option><option value='2'>image</option><option value='3'>select</option>
                    </select>
                </div>
            </div>

			<div class="layui-form-item">
				<label class="layui-form-label">内容</label>
				<div class="layui-input-block">
				    <link href="/static/umeditor/themes/default/css/umeditor.css" type="text/css" rel="stylesheet">
				    <script type="text/javascript" src="/static/umeditor/third-party/jquery.min.js"></script>
				    <script type="text/javascript" src="/static/umeditor/third-party/template.min.js"></script>
				    <script type="text/javascript" charset="utf-8" src="/static/umeditor/umeditor.config.js"></script>
				    <script type="text/javascript" charset="utf-8" src="/static/umeditor/umeditor.min.js"></script>
				    <script type="text/javascript" src="/static/umeditor/lang/zh-cn/zh-cn.js"></script>

					<script type="text/plain" id="myEditor" name="content" style="width:860px;height:240px;">
					    <p>这里我可以写一些输入提示</p>
					</script>
					<script type="text/javascript">
					    var um = UM.getEditor("myEditor");
					</script>
				</div>
			</div>


			<div class="layui-form-item">
				<div class="layui-input-block">
					<button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
					<button type="reset" class="layui-btn layui-btn-primary">重置</button>
				</div>
			</div>
		</div>
		<div class="right-box">
		</div>
			
	</form>

	<script type="text/javascript">

		layui.use(['form'], function(){
	  		var form = layui.form();
			form.on('submit(formDemo)', function(data){
				$.post(data.form.action,data.field,function(res){
					if(res.code == 1){
						window.location.href = $(data.form).attr('skipurl');
					}else{
						layer.msg(res.msg);
					}
				});
				return false;
			});

		})
	</script>
</div>


		
	</body>
</html>