<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:70:"F:\PersonalWorks\boke\public/../application/index\view\\page\page.html";i:1494767851;s:66:"F:\PersonalWorks\boke\public/../application/index\view\layout.html";i:1494765363;s:73:"F:\PersonalWorks\boke\public/../application/index\view\public\header.html";i:1494730816;s:70:"F:\PersonalWorks\boke\public/../application/index\view\public\nav.html";i:1494767980;s:73:"F:\PersonalWorks\boke\public/../application/index\view\public\footer.html";i:1494762008;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
<script type="text/javascript" src="/static/layui/layui.js"></script>
<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<style type="text/css">
		.layui-nav{z-index: 99999;}
		.boke-wrap{max-width: 1100px;margin:0 auto;overflow: hidden;zoom: 1;margin-top: 10px;}
		.layui-main{height: 1200px;background-color: #ddd;}
		footer{width: 100%;height: 48px;background-color: #393D49;padding-top: 20px;}
		footer p{text-align: center;color: #fff;padding: 2px;}
	</style>
</head>
<body>
<style type="text/css">
	header{background-color: #393D49;height: 60px;width: 100%;}
	.logo{position: absolute;color: #fff;top: 0px;z-index: 99999999;font-size: 18px;height: 60px;line-height: 60px;left: 0%;}
	.layui-nav{padding-left: 12%;border-radius: 0px;}
	.fa-list{font-size: 18px;color: #fff;height: 60px;line-height: 60px;margin-left:20px;display: none;}

	@media screen and (max-width: 680px) {
	    .layui-nav-tree{display: none;padding-left:0px;width: 100%;}
	    .layui-nav{display: none;}
	    .logo{left: 50%;margin-left: -50px;}
	    .fa-list{display: block;}
	}
	@media screen and (min-width: 680px) and (max-width: 1180px) {
	    .layui-nav{padding-left: 19%;display: block;}
	    .layui-nav-tree{display: none;}
	    .logo{left: 3%;}
	}
	@media screen and (min-width: 1180px) {
	    .layui-nav{padding-left: 13%;display: block;}
	    .layui-nav-tree{display: none;}
	    .logo{left: 3%;}
	}
</style>
<header>
	<?php $menu = (new app\admin\model\MMenu)->getTreeArray();
	?>
	<i class="fa fa-list" onclick="showNav()"></i>
	<ul class="layui-nav layui-nav-tree">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="layui-nav-item">
				<?php if(!empty($vo['child'])): ?>
					<a href="javascript:;"><?php echo $vo['name']; ?></a>
					<dl class="layui-nav-child">
					<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<dd><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a></dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
					</dl>
				<?php else: ?>
					<a href="<?php echo $vo['url']; ?>"><?php echo $vo['name']; ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>

	<div class="logo">
		FUYUN-博客
	</div>
	<ul class="layui-nav">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="layui-nav-item">
				<?php if(!empty($vo['child'])): ?>
					<a href="javascript:;"><?php echo $vo['name']; ?></a>
					<dl class="layui-nav-child">
					<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<dd><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a></dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
					</dl>
				<?php else: ?>
					<a href="<?php echo $vo['url']; ?>"><?php echo $vo['name']; ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>
 
<script>
//注意：导航 依赖 element 模块，否则无法进行功能性操作
layui.use('element', function(){});

function showNav(){
	$(".layui-nav-tree").toggle();
}
</script>
</header>

<style type="text/css">	
	.page-page{max-width: 800px;}
</style>
<div class="boke-wrap page-page">
	<div class="boke-title">
		<span class="layui-breadcrumb">
			<a href="/">博客</a>
			<a><cite><?php echo $model['title']; ?></cite></a>
		</span>
	</div>

	<div class="">
		<?php echo $model['content']; ?>
	</div>

</div>


<footer>
	<p>fuyun博客 email:1440030538@qq.com</p>
	<p>浙ICP备17001674号-1</p>
</footer>

<script type="text/javascript">
	document_height = $(document).height()-138;
	$(".boke-wrap").css('min-height',document_height+"px");
	// console.log(document_height);
</script>
</body>
</html>