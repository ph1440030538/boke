<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:67:"F:\PersonalWorks\boke\public/../application/admin\view\at\test.html";i:1494425588;s:66:"F:\PersonalWorks\boke\public/../application/admin\view\layout.html";i:1493954682;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_header.html";i:1494253897;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
	</head>
<body>

 <form class="layui-form" method="post">
	<div class="layui-form-item">
		<label class="layui-form-label">分类名字</label>
		<div class="layui-input-block">
			<input type="text" name="name" placeholder="请输入分类名字" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">父级id</label>
		<div class="layui-input-block">
			<input type="text" name="parent_id" placeholder="请输入父级id" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">列表模板</label>
		<div class="layui-input-block">
			<input type="text" name="list_tpl" placeholder="请输入列表模板" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">页面模板</label>
		<div class="layui-input-block">
			<input type="text" name="article_tpl" placeholder="请输入页面模板" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">seo标题</label>
		<div class="layui-input-block">
			<input type="text" name="seo_title" placeholder="请输入seo标题" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">seo关键词</label>
		<div class="layui-input-block">
			<input type="text" name="seo_keywords"  placeholder="请输入seo关键词" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">seo描述</label>
		<div class="layui-input-block">
			<input type="text" name="seo_desribe" placeholder="请输入seo描述" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">创建时间</label>
		<div class="layui-input-block">
			<input type="text" name="create_time" placeholder="请输入创建时间" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">更新时间</label>
		<div class="layui-input-block">
			<input type="text" name="update_time" placeholder="请输入更新时间" class="layui-input">
		</div>
	</div>
	<div class="layui-form-item">
		<label class="layui-form-label">状态</label>
		<div class="layui-input-block">
			<select name="status">
				<option value='0'>不显示</option><option value='1'>显示</option><option value='111'>删除</option>
			</select>
		</div>
	</div>
	<div class="layui-form-item">
		<div class="layui-input-block">
			<button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
			<button type="reset" class="layui-btn layui-btn-primary">重置</button>
		</div>
	</div>
</form>

<script type="text/javascript">
	layui.use('form', function(){
  		var form = layui.form();

		form.on('submit(*)', function(data){
			return true;
		});

	})
</script>


	</body>
</html>