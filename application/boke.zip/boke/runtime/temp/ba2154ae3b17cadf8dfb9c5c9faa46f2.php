<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:71:"F:\PersonalWorks\boke\public/../application/index\view\\list\share.html";i:1494762550;s:66:"F:\PersonalWorks\boke\public/../application/index\view\layout.html";i:1494765363;s:73:"F:\PersonalWorks\boke\public/../application/index\view\public\header.html";i:1494730816;s:70:"F:\PersonalWorks\boke\public/../application/index\view\public\nav.html";i:1494767980;s:73:"F:\PersonalWorks\boke\public/../application/index\view\public\footer.html";i:1494762008;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
<script type="text/javascript" src="/static/layui/layui.js"></script>
<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
	<meta name="viewport" content="width=device-width,initial-scale=1.0, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no"/>
	<style type="text/css">
		.layui-nav{z-index: 99999;}
		.boke-wrap{max-width: 1100px;margin:0 auto;overflow: hidden;zoom: 1;margin-top: 10px;}
		.layui-main{height: 1200px;background-color: #ddd;}
		footer{width: 100%;height: 48px;background-color: #393D49;padding-top: 20px;}
		footer p{text-align: center;color: #fff;padding: 2px;}
	</style>
</head>
<body>
<style type="text/css">
	header{background-color: #393D49;height: 60px;width: 100%;}
	.logo{position: absolute;color: #fff;top: 0px;z-index: 99999999;font-size: 18px;height: 60px;line-height: 60px;left: 0%;}
	.layui-nav{padding-left: 12%;border-radius: 0px;}
	.fa-list{font-size: 18px;color: #fff;height: 60px;line-height: 60px;margin-left:20px;display: none;}

	@media screen and (max-width: 680px) {
	    .layui-nav-tree{display: none;padding-left:0px;width: 100%;}
	    .layui-nav{display: none;}
	    .logo{left: 50%;margin-left: -50px;}
	    .fa-list{display: block;}
	}
	@media screen and (min-width: 680px) and (max-width: 1180px) {
	    .layui-nav{padding-left: 19%;display: block;}
	    .layui-nav-tree{display: none;}
	    .logo{left: 3%;}
	}
	@media screen and (min-width: 1180px) {
	    .layui-nav{padding-left: 13%;display: block;}
	    .layui-nav-tree{display: none;}
	    .logo{left: 3%;}
	}
</style>
<header>
	<?php $menu = (new app\admin\model\MMenu)->getTreeArray();
	?>
	<i class="fa fa-list" onclick="showNav()"></i>
	<ul class="layui-nav layui-nav-tree">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="layui-nav-item">
				<?php if(!empty($vo['child'])): ?>
					<a href="javascript:;"><?php echo $vo['name']; ?></a>
					<dl class="layui-nav-child">
					<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<dd><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a></dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
					</dl>
				<?php else: ?>
					<a href="<?php echo $vo['url']; ?>"><?php echo $vo['name']; ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>

	<div class="logo">
		FUYUN-博客
	</div>
	<ul class="layui-nav">
		<?php if(is_array($menu) || $menu instanceof \think\Collection || $menu instanceof \think\Paginator): $i = 0; $__LIST__ = $menu;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			<li class="layui-nav-item">
				<?php if(!empty($vo['child'])): ?>
					<a href="javascript:;"><?php echo $vo['name']; ?></a>
					<dl class="layui-nav-child">
					<?php if(is_array($vo['child']) || $vo['child'] instanceof \think\Collection || $vo['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
						<dd><a href="<?php echo $v['url']; ?>"><?php echo $v['name']; ?></a></dd>
					<?php endforeach; endif; else: echo "" ;endif; ?>
					</dl>
				<?php else: ?>
					<a href="<?php echo $vo['url']; ?>"><?php echo $vo['name']; ?></a>
				<?php endif; ?>
			</li>
		<?php endforeach; endif; else: echo "" ;endif; ?>
	</ul>
 
<script>
//注意：导航 依赖 element 模块，否则无法进行功能性操作
layui.use('element', function(){});

function showNav(){
	$(".layui-nav-tree").toggle();
}
</script>
</header>

<style type="text/css">	
	*{padding: 0px;margin:0px;}
	
	article{background-color: #efefef;float: left;}
	.boke-title{margin-left: 0.8%;}
	.resource-cover img{-webkit-animation:imgBig 1s;animation:imgBig 1s;width: 100%;height: 196px;}
	.resource-button{text-align: center;padding-top: 10px;border-top: 1px dashed #ddd;}
	.resource-button button{text-align: center;width: 33%;padding: 0px;text-align: center;}
	.resource-title h3{text-align: center;font-size: 23px;color: #393D49;padding: 3px 0px;}
	.resource-title p{font-size: 13px;color: #666;padding: 3px 2px 6px;}

	@media screen and (max-width: 680px) {
	    article{margin:3%;width: 88%;padding: 3%;}
	}
	@media screen and (min-width: 680px) and (max-width: 1180px) {
	    article{margin:1%;width: 29.8%;padding: 0.6%;}
	}
	@media screen and (min-width: 1180px) {
	    article{margin:0.8%;width: 22.2%;padding: 0.6%;}
	}

	@keyframes imgBig
	{
		from {width:0px;}
		to {width:100%;}
	}
	@-webkit-keyframes imgBig
	{
		from {width:0px;}
		to {width:100%;}
	}
</style>

<div class="share-page boke-wrap">
	<div class="boke-title">
		<span class="layui-breadcrumb">
			<a href="/">首页</a>
			<a href="javascript:;">作品展示</a>
			<a><cite><?php echo $category['name']; ?></cite></a>
		</span>
	</div>
	<div class="box">
		<?php foreach($list['data'] as $vo):?>
			<article>
				<div class="resource-cover">
					<img src="<?php echo $vo['cover']; ?>">
				</div>
				<div class="resource-title">
					<h3><?php echo $vo['title']; ?></h3>
					<p><?php echo $vo['describe']; ?></p>
				</div>
				<div class="resource-button">
					<button class="layui-btn layui-btn-primary">
						<i class="fa fa-eye fa-fw"></i>演示
					</button>
					<button class="layui-btn layui-btn-primary">
						<i class="fa fa-download fa-fw"></i>下载
					</button>
				</div>
			</article>
		<?php endforeach?>
        <div class="page">
            <div id="page"></div>
        </div>

	</div>
</div>
<script type="text/javascript">
    layui.use(['laypage', 'layer','form'], function(){
        var laypage = layui.laypage
        ,layer = layui.layer;
        laypage({
            cont: 'page'
            ,pages: <?php echo $list['pages']; ?> //总页数
            ,groups: 5 //连续显示分页数
            ,curr: <?php echo $list['curPage']; ?>
            ,skip: true
            ,jump: function(obj, first){
                if(!first){
                    var url = window.location.href;
                    if(url.indexOf("?")==-1){
                        window.location.href = url+"?page="+obj.curr;
                    }else{
                        if(url.indexOf("page")==-1){
                            window.location.href = url+"&page="+obj.curr;
                        }else{
                            window.location.href = url.replace(/page=\d*/, 'page='+obj.curr)
                        }                                        
                    }
                }                       
            }
        });
    });
</script>


<footer>
	<p>fuyun博客 email:1440030538@qq.com</p>
	<p>浙ICP备17001674号-1</p>
</footer>

<script type="text/javascript">
	document_height = $(document).height()-138;
	$(".boke-wrap").css('min-height',document_height+"px");
	// console.log(document_height);
</script>
</body>
</html>