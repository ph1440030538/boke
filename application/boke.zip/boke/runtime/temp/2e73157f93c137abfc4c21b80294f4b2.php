<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:74:"F:\PersonalWorks\boke\public/../application/admin\view\category\index.html";i:1494719558;s:66:"F:\PersonalWorks\boke\public/../application/admin\view\layout.html";i:1493954682;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_header.html";i:1494647407;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .boke-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		    .boke-wrap .boke-search{padding: 10px 20px;background-color: #efefef;}
		    .boke-wrap .boke-search .layui-inline{margin-right: 18px;}
			.boke-wrap .boke-table tfoot{background-color: #efefef;}
		</style>
	</head>
<body>

 <style type="text/css">
    .page-title{position: relative;}
    .page-title h1{background-color: #fff;font-size: 20px;color:#393D49;font-weight: 300;padding: 10px 30px 10px 20px;border-bottom: 1px solid #dfdfdf;}
    .add-btn{float: right;margin-right: 20px;}
    .search-submit{margin-top: 20px;}
    .btn-box{margin-left: 10px;}
    .layui-table tfoot,.search-box {background-color: #efefef;}
    .search-box{padding: 10px 20px;}
    .search-box .layui-inline{margin: 3px;}
</style>
<div class="boke-wrap">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li class="layui-this">分类列表</li>
            <li><a href="<?php echo Url('add'); ?>">添加分类</a></li>
        </ul>
    </div>

    <div class="">
        <table class="layui-form layui-table" lay-skin="line">
            <colgroup>
                <col width="100">
                <col>
                <col width="100">
                <col width="200">
            </colgroup>

            <thead>
                <tr>
                    <td>id</td>
                    <th>分类名字</th>
                    <th>排序</th>
                    <th>操作</th>
                </tr> 
            </thead>
            <tbody>
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr data-id="<?php echo $vo['id']; ?>">
                        <td><?php echo $vo['id']; ?></td>
                        <td>
                            <?php echo $vo['name']; ?>
                        </td>
                        <td><input class="layui-input" type="text" value="<?php echo $vo['sort']; ?>"></td>
                        <td>
                            <a class="layui-btn layui-btn-mini" href="<?php echo Url('add'); ?>?id=<?php echo $vo['id']; ?>">添加子菜单</a>
                            <a class="layui-btn layui-btn-mini" href="<?php echo Url('edit'); ?>?id=<?php echo $vo['id']; ?>">编辑</a>
                            <a class="layui-btn layui-btn-mini layui-btn-danger" href="javascript:;" onclick="del(<?php echo $vo['id']; ?>)" >删除</a>
                        </td>
                    </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
        </table>
    </div>

    <script type="text/javascript">
        layui.use(['layer']);
        function del(id){
            layer.confirm('是否确定删除？', {
                btn: ['是','否'] //按钮
            }, function(){
                $.ajax({
                    type : 'post',
                    url : "<?php echo Url('deleteAll'); ?>",
                    data : {id:id},
                    dataType: 'json',
                    success: function(result){
                        if(result['status'] == 200){
                            $("tr[data-id="+id+"]").remove();
                            layer.closeAll();
                        }else{
                            layer.msg(result.msg);
                        }
                    }
                });
            });
        }
    </script>
</div>

	</body>
</html>