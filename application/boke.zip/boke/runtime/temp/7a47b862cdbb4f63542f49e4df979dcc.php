<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:54:"G:\boke\public/../application/admin\view\at\index.html";i:1494848711;s:52:"G:\boke\public/../application/admin\view\layout.html";i:1494768442;s:66:"G:\boke\public/../application/admin\view\public\layout_header.html";i:1494647407;s:66:"G:\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .boke-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		    .boke-wrap .boke-search{padding: 10px 20px;background-color: #efefef;}
		    .boke-wrap .boke-search .layui-inline{margin-right: 18px;}
			.boke-wrap .boke-table tfoot{background-color: #efefef;}
		</style>
	</head>
<body>

 <style type="text/css">
	body{background-color: #fff;}
	.at-index{padding-top: 20px;}
	/*.layui-form-item{text-align: center;}*/
	.strtotime-box{background-color: #efefef;padding: 8px 3px 2px;}
	.form-group{padding: 10px 0px;}
	.index_list{padding: 5px 0px;}
	.index_list .layui-inline{max-width: 20%;}
	.select_value{display: none;}
	.layui-table{width: 80%;margin:0 auto;}
</style>
<script type="text/javascript" src="https://cdn.bootcss.com/vue/2.3.3/vue.min.js"></script>
<div class="at-index" id="at-index">
	<fieldset class="layui-elem-field layui-field-title">
	 	<legend>自动生成</legend>
	</fieldset>

	<form class="layui-form" action="<?php echo Url('admin/at/doing'); ?>" method="post">
		<div class="form-group">
			<blockquote class="layui-elem-quote">
				控制器，模块，验证
			</blockquote>
			<div class="layui-form-item strtotime-box">
			  	<div class="layui-inline">
				    <label class="layui-form-label">创建时间戳</label>
				    <div class="layui-input-block">
				    	<input type="text" class="layui-input" >
				    </div>
			  	</div>
			  	<div class="layui-inline">
				    <label class="layui-form-label">更新时间戳</label>
				    <div class="layui-input-block">
				    	<input type="text" class="layui-input">
				    </div>
			  	</div>
			</div>

		</div>

		<div class="form-group">
			<blockquote class="layui-elem-quote">
				页面
			</blockquote>
			
			<table class="layui-table" lay-even>
				<thead>
					<tr>
						<th width="25%">字段</th>
						<th width="25%">字段名字</th>
						<th width="25%">字段类型</th>
						<th width="25%">操作</th>
					</tr> 
				</thead>
				<tbody>
					<?php if(is_array($fields) || $fields instanceof \think\Collection || $fields instanceof \think\Paginator): $i = 0; $__LIST__ = $fields;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$field): $mod = ($i % 2 );++$i;?>
						<tr>
							<td>
							  	<?php echo $field['alias']; ?>
							</td>
							<td>
							    <input type="text" class="layui-input" value="<?php echo $field['name']; ?>">
							</td>
							<td>
								<div class="layui-block">
							    	<select class="type"  lay-filter="type">
										<option value="input">文本</option>
										<option value="select">select</option>
										<option value="image">图片</option>
							    	</select>
								</div>
								<div class="layui-block select_value">
									<input type="text" class="layui-input" placeholder="例如：0=>未审核,1=>通过,2=>不通过">
								</div>
							</td>
							<td>
								<div class="layui-inline">
							    	<input type="checkbox" name="" lay-skin="primary" title="列表页" checked="">
							    	<input type="checkbox" name="" lay-skin="primary" title="增加编辑页面" checked="">
						    	</div>
							</td>
						</tr>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</tbody>
			</table>
		</div>

		<div class="layui-form-item" style="text-align:center;">
			<div class="layui-input-block">
				<button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
			</div>
		</div>
		
	</form>

	<script type="text/javascript">
		layui.use('form', function(){
	  		var form = layui.form();

			form.on('submit(*)', function(data){
				return true; //阻止表单跳转。如果需要表单跳转，去掉这段即可。
			});

			form.on('select(type)', function(data){
				if(data.value == 'select'){
					$(this).parent().parent().parent().parent().find(".select_value").css("display","block");
				}else{
					$(this).parent().parent().parent().parent().find(".select_value").css("display","none");
				}
			});

		})



	</script>
</div>
	</body>
</html>