<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:59:"G:\boke\public/../application/admin\view\category\edit.html";i:1494573721;s:52:"G:\boke\public/../application/admin\view\layout.html";i:1493954682;s:66:"G:\boke\public/../application/admin\view\public\layout_header.html";i:1494471946;s:66:"G:\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .fuyun-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		</style>
	</head>
<body>

 <style type="text/css">
	.category-add{margin: 15px;}
	.layui-form{width: 60%;margin-left: 10%;}
</style>

<div class="category-add">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li><a href="<?php echo Url('admin/category/index'); ?>">分类列表</a></li>
            <li class="layui-this">添加分类</li>
        </ul>
    </div>

    <form class="layui-form" action="<?php echo Url('admin/category/edit'); ?>" method="post">
		<div class="layui-form-item">
			<label class="layui-form-label">上级分类</label>
			<div class="layui-input-block">
				<select name="parent_id" lay-verify="">
					<option value="">请选择分类</option>
					<option value="0">最高级</option>
					<?php if(is_array($categoryList) || $categoryList instanceof \think\Collection || $categoryList instanceof \think\Paginator): $i = 0; $__LIST__ = $categoryList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$category): $mod = ($i % 2 );++$i;?>
						<option value="<?php echo $category['id']; ?>" <?php if($category['id']==$model['id']){echo 'selected';} ?> ><?php echo $category['name']; ?></option>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</select>   
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">分类名字</label>
			<div class="layui-input-block">
				<input type="text" name="name" lay-verify="title" autocomplete="off" placeholder="请输入分类名字" class="layui-input" value="<?php echo $model['name']; ?>" />
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">seo标题</label>
			<div class="layui-input-block">
				<input type="text" name="seo_title" lay-verify="title" autocomplete="off" placeholder="请输入seo标题" class="layui-input" value="<?php echo $model['seo_title']; ?>" />
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">seo关键字</label>
			<div class="layui-input-block">
				<input type="text" name="seo_keywords" lay-verify="seo_keywords" autocomplete="off" placeholder="请输入seo关键字" class="layui-input" value="<?php echo $model['seo_keywords']; ?>" />
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">seo描述</label>
			<div class="layui-input-block">
				<input type="text" name="seo_desribe" lay-verify="seo_desribe" autocomplete="off" placeholder="请输入seo描述" class="layui-input" value="<?php echo $model['seo_desribe']; ?>" />
			</div>
		</div>

		<div class="layui-form-item">
			<label class="layui-form-label">列表模板</label>
			<div class="layui-input-block">
				<select name="list_tpl" lay-verify="aihao">
					<option value="0">暂不选择</option>
					<?php foreach($listTpl as $key => $vo): ?>
						<option <?php if($vo == $model['list_tpl']): ?>selected<?php endif; ?> value="<?php echo $vo; ?>"><?php echo $vo; ?></option>
					<?php endforeach; ?>
				</select>   
			</div>
		</div>

		<div class="layui-form-item">
			<label class="layui-form-label">文章模板</label>
			<div class="layui-input-block">
				<select name="article_tpl" lay-verify="aihao">
					<option value="0">暂不选择</option>
					<?php foreach($pageTpl as $key => $vo): ?>
						<option <?php if($vo == $model['article_tpl']): ?>selected<?php endif; ?> value="<?php echo $vo; ?>"><?php echo $vo; ?></option>
					<?php endforeach; ?>
				</select>   
			</div>
		</div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<input type="hidden" name="id" value="<?php echo $model['id']; ?>">
				<button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
			</div>
		</div>

    </form>

	<script>
		layui.use('form', function(){
		  var form = layui.form();
			form.on('submit(formDemo)', function(data){
				// console.log(data);
				return true;
			});
		  //各种基于事件的操作，下面会有进一步介绍
		});
	</script>

</div>

	</body>
</html>