<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:56:"G:\boke\public/../application/admin\view\boke\index.html";i:1494554659;s:52:"G:\boke\public/../application/admin\view\layout.html";i:1493954682;s:66:"G:\boke\public/../application/admin\view\public\layout_header.html";i:1494471946;s:66:"G:\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .fuyun-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		</style>
	</head>
<body>

 <style type="text/css">
.layui-search{padding: 10px;border: 1px solid #ddd;background-color: #ddd;}
.layui-search .layui-form-label{text-align:left;}
layui-form-label
</style>
<div class="fuyun-wrap">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li class="layui-this">分类列表</li>
            <li><a href=<?php echo Url("add"); ?>>添加分类</a></li>
        </ul>
    </div>
    
    <div class="layui-search">
<!--         <div class="layui-inline">
            <label class="layui-form-label">名字</label>
            <input type="text" name="content" class="layui-input">
        </div>
        <div class="layui-inline">
            <label class="layui-form-label">&nbsp;</label>
            <div>
                <input type="button" class="layui-btn" name="content" class="layui-input" value="搜索">
            </div>
        </div> -->
    </div>

    <div class="fuyun-content">
        <table class="layui-table">
            <thead>
                <tr>
                    <th width="10%">标题</th>
                    <th width="10%">关键字</th>
                    <th width="10%">描述</th>
                    <th width="10%">内容</th>
                    <th width="10%">文章来源</th>
                    <th width="10%">article_tpl</th>
                    <th width="10%">create_time</th>
                    <th width="10%">update_time</th>
                    <th width="10%">操作</th>
                </tr> 
            </thead>
            <tbody>
                <?php if(is_array($lists) || $lists instanceof \think\Collection || $lists instanceof \think\Paginator): $i = 0; $__LIST__ = $lists;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr data-id="<?php echo $vo['id']; ?>">
                        <td class='layui-elip'><?php echo $vo['title']; ?></td>
                        <td class='layui-elip'><?php echo $vo['keywords']; ?></td>
                        <td class='layui-elip'><?php echo $vo['describe']; ?></td>
                        <td class='layui-elip'><?php echo $vo['content']; ?></td>
                        <td class='layui-elip'><?php echo $vo['source']; ?></td>
                        <td class='layui-elip'><?php echo $vo['article_tpl']; ?></td>
                        <td class='layui-elip'><?php echo $vo['create_time']; ?></td>
                        <td class='layui-elip'><?php echo $vo['update_time']; ?></td>
                        <td>
                            <a href="<?php echo Url('edit'); ?>?id=<?php echo $vo['id']; ?>">编辑</a>/
                            <a href="javascript:;" onclick="del(<?php echo $vo['id']; ?>)" >删除</a>
                        </td>
                    </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
        </table>

        <div class="page">
            <div id="demo1"></div>
            <script>
                layui.use(['laypage', 'layer'], function(){
                    var laypage = layui.laypage
                    ,layer = layui.layer;
                    laypage({
                        cont: 'demo1'
                        ,pages: <?php echo $pages; ?> //总页数
                        ,groups: 5 //连续显示分页数
                        ,curr: <?php echo $curPage; ?>
                        ,skip: true
                        ,jump: function(obj, first){
                            if(!first){
                                var url = window.location.href;
                                if(url.indexOf("?")==-1){
                                    window.location.href = url+"?page="+obj.curr;
                                }else{
                                    if(url.indexOf("page")==-1){
                                        window.location.href = url+"&page="+obj.curr;
                                    }else{
                                        window.location.href = url.replace(/page=\d*/, 'page='+obj.curr)
                                    }                                        
                                }
                            }                       
                        }
                    });
                });
            </script>
        </div>
    </div>

    <script type="text/javascript">
        function del(id){
            layer.confirm('是否确定删除？', {
                btn: ['是','否'] //按钮
            }, function(){
                $.ajax({
                    type : 'get',
                    url : "<?php echo Url('delete'); ?>",
                    data : {id:id},
                    dataType: 'json',
                    success: function(result){
                        if(result['status'] == 200){
                            $("tr[data-id="+id+"]").remove();
                            layer.closeAll();
                        }else{
                            layer.msg(result.msg);
                        }
                    }
                });
            });
        }
    </script>
</div>

	</body>
</html>