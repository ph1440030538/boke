<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:69:"F:\PersonalWorks\boke\public/../application/admin\view\menu\edit.html";i:1494691802;s:66:"F:\PersonalWorks\boke\public/../application/admin\view\layout.html";i:1493954682;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_header.html";i:1494647407;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .boke-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		    .boke-wrap .boke-search{padding: 10px 20px;background-color: #efefef;}
		    .boke-wrap .boke-search .layui-inline{margin-right: 18px;}
			.boke-wrap .boke-table tfoot{background-color: #efefef;}
		</style>
	</head>
<body>

 <style type="text/css">
	.layui-form{width: 60%;margin-left: 10%;}
</style>

<div class="boke-wrap">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li><a href="<?php echo Url('index'); ?>">菜单列表</a></li>
            <li class="layui-this">编辑菜单</li>
        </ul>
    </div>

    <form class="layui-form" action="<?php echo Url('edit'); ?>" method="post">
		<div class="layui-form-item">
			<label class="layui-form-label">上级菜单</label>
			<div class="layui-input-inline">
				<select name="parent_id">
					<option value="0">最高级</option>
					<?php echo $option; ?>
				</select>
			</div>
		</div>

		<div class="layui-form-item">
			<label class="layui-form-label">分类名字</label>
			<div class="layui-input-inline">
				<input type="text" name="name" value="<?php echo $model['name']; ?>" placeholder="请输入分类名字" class="layui-input">
			</div>
		</div>
		<div class="layui-form-item">
			<label class="layui-form-label">排序</label>
			<div class="layui-input-inline">
				<input type="text" name="sort" value="<?php echo $model['sort']; ?>" placeholder="请输入排序" class="layui-input">
			</div>
		</div>

		<div class="layui-form-item">
			<label class="layui-form-label">地址</label>
			<div class="layui-input-block">
				<input type="text" name="url" value="<?php echo $model['url']; ?>" placeholder="请输入地址" class="layui-input">
			</div>
		</div>
		<div class="layui-form-item">
			<div class="layui-input-block">
				<input type="hidden" name="id" value="<?php echo $model['id']; ?>">
				<button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
				<button type="reset" class="layui-btn layui-btn-primary">重置</button>
			</div>
		</div>

    </form>

	<script>
		layui.use('form', function(){
		  var form = layui.form();
			form.on('submit(formDemo)', function(data){
				// console.log(data);
				return true;
			});
		  //各种基于事件的操作，下面会有进一步介绍
		});
	</script>

</div>

	</body>
</html>