<?php if (!defined('THINK_PATH')) exit(); /*a:5:{s:58:"G:\boke\public/../application/admin\view\common\login.html";i:1494730144;s:52:"G:\boke\public/../application/admin\view\layout.html";i:1494768442;s:66:"G:\boke\public/../application/admin\view\public\layout_header.html";i:1494647407;s:59:"G:\boke\public/../application/admin\view\public\header.html";i:1494253873;s:66:"G:\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .boke-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		    .boke-wrap .boke-search{padding: 10px 20px;background-color: #efefef;}
		    .boke-wrap .boke-search .layui-inline{margin-right: 18px;}
			.boke-wrap .boke-table tfoot{background-color: #efefef;}
		</style>
	</head>
<body>

 	<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>demo</title>
	<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
	<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
	<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
	<script type="text/javascript" src="/static/layui/layui.js"></script>
	
	<link rel="stylesheet" href="/static/css/login.css" />
	<script type="text/javascript" src="http://cdn.bootcss.com/particles.js/2.0.0/particles.min.js"></script>
	<style type="text/css">
		#particles-js{width: 100%;height: 100%;position: absolute;top: 0px;left: 0px;z-index: -9;}
		.login_box{position: absolute;width: 400px;height: 220px;top:50%;left:50%;margin-top: -110px;margin-left: -250px;border-radius: 3px;opacity: 0.8;background-color: #efefef;}
		.login_box .layui-form-item{width: 90%;}
		.login_box h2{text-align: center;font-size: 32px;margin-left: 90px;}
		.beg-login-bg{;background-color: #efefef;}
	</style>
</head>
<body class="beg-login-bg">
	<div class="login_box">
		<form class="layui-form" method="post">
			<div class="layui-form-item">
				<h2>管理后台</h2>
			</div>

			<div class="layui-form-item">
				<div class="layui-input-block">
					<input type="text" name="username" lay-verify="required" placeholder="请输入用户名" class="layui-input">
				</div>
			</div>


			<div class="layui-form-item">
				<div class="layui-input-block">
					<input type="password" name="password" lay-verify="required" placeholder="请输入密码" class="layui-input">
				</div>
			</div>

			<div class="layui-form-item">
				<div class="layui-input-block">
					<input type="hidden" name="__token__" value="<?php echo $token; ?>">
					<button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
				</div>
			</div>


		</form>
	</div>
	<div id="particles-js"></div>

	
	<script>
		layui.use(['layer', 'form'], function() {
			var layer = layui.layer,
				$ = layui.jquery,
				form = layui.form();
				
			form.on('submit(formDemo)',function(data){
				$.post("<?php echo Url('dologin'); ?>",data.field,function(res){
					if(res.status == 200){
						window.location.href = "<?php echo Url('login'); ?>";
					}else{
						layer.msg(res.msg);
					}
				});
				return false;
			});
		});
	</script>


	<script type="text/javascript">


particlesJS("particles-js", {
  "particles": {
    "number": {
      "value": 100,
      "density": {
        "enable": true,
        "value_area": 800
      }
    },
    "color": {
      "value": "#666"
    },
    "shape": {
      "type": "circle",
      "stroke": {
        "width": 0,
        "color": "#000000"
      },
      "polygon": {
        "nb_sides": 5
      },
      "image": {
        "src": "img/github.svg",
        "width": 100,
        "height": 100
      }
    },
    "opacity": {
      "value": 0.5,
      "random": false,
      "anim": {
        "enable": false,
        "speed": 1,
        "opacity_min": 0.1,
        "sync": false
      }
    },
    "size": {
      "value": 3,
      "random": true,
      "anim": {
        "enable": false,
        "speed": 40,
        "size_min": 0.1,
        "sync": false
      }
    },
    "line_linked": {
      "enable": true,
      "distance": 150,
      "color": "#666666",
      "opacity": 0.4,
      "width": 1
    },
    "move": {
      "enable": true,
      "speed": 2,
      "direction": "none",
      "random": false,
      "straight": false,
      "out_mode": "out",
      "bounce": false,
      "attract": {
        "enable": false,
        "rotateX": 600,
        "rotateY": 1200
      }
    }
  },
  "interactivity": {
    "detect_on": "canvas",
    "events": {
      "onhover": {
        "enable": true,
        "mode": "grab"
      },
      "onclick": {
        "enable": true,
        "mode": "push"
      },
      "resize": true
    },
    "modes": {
      "grab": {
        "distance": 140,
        "line_linked": {
          "opacity": 1
        }
      },
      "bubble": {
        "distance": 400,
        "size": 40,
        "duration": 2,
        "opacity": 8,
        "speed": 3
      },
      "repulse": {
        "distance": 200,
        "duration": 0.4
      },
      "push": {
        "particles_nb": 4
      },
      "remove": {
        "particles_nb": 2
      }
    }
  },
  "retina_detect": true
});
	</script>

</body>
<html>
	</body>
</html>