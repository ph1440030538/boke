<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:74:"F:\PersonalWorks\boke\public/../application/admin\view\boketest\index.html";i:1494775189;s:66:"F:\PersonalWorks\boke\public/../application/admin\view\layout.html";i:1494768442;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_header.html";i:1494647407;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .boke-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		    .boke-wrap .boke-search{padding: 10px 20px;background-color: #efefef;}
		    .boke-wrap .boke-search .layui-inline{margin-right: 18px;}
			.boke-wrap .boke-table tfoot{background-color: #efefef;}
		</style>
	</head>
<body>

 <div class="boke-wrap">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li class="layui-this">测试列表</li>
            <li><a href="<?php echo Url('add'); ?>">添加测试</a></li>
        </ul>
    </div>

    <div class="boke-table">
        <table class="layui-table layui-form">
            <thead>
                <tr>
                    <th width="3%"><input type="checkbox" name="" lay-skin="primary" lay-filter="allChoose"></th>
                    
<th>名字</th>
<th>关键字</th>
<th>类型</th>
<th>内容</th>
<th>状态</th>
                    <th width="10%">操作</th>
                </tr> 
            </thead>
            <tbody>
                <?php if(is_array($list['data']) || $list['data'] instanceof \think\Collection || $list['data'] instanceof \think\Paginator): $i = 0; $__LIST__ = $list['data'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr data-id="<?php echo $vo['id']; ?>">
                        <td><input type="checkbox" name="checkboxId[]" lay-skin="primary" value="<?php echo $vo['id']; ?>" ></td>
                        
<td class='layui-elip'><?php echo $vo['name']; ?></td>
<td class='layui-elip'><?php echo $vo['keyword']; ?></td>
<td class='layui-elip'><?php echo $vo['type']; ?></td>
<td class='layui-elip'><?php echo $vo['content']; ?></td>
<td class='layui-elip'><?php echo $vo['status']; ?></td>
                        <td>
                            <a class="layui-btn layui-btn-mini" href="<?php echo Url('edit'); ?>?id=<?php echo $vo['id']; ?>">编辑</a>
                            <a class="layui-btn layui-btn-mini layui-btn-danger" href="javascript:;" onclick="del(<?php echo $vo['id']; ?>)" >删除</a>
                        </td>
                    </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td colspan="10"><button onclick="deleteAll()" class="layui-btn layui-btn-small">删除</button></td>
                </tr>
            </tfoot>
        </table>

        <div class="page">
            <div id="page"></div>
        </div>
    </div>

    <script type="text/javascript">
        layui.use(['laypage', 'layer','form'], function(){
            var laypage = layui.laypage
            ,layer = layui.layer;
            laypage({
                cont: 'page'
                ,pages: <?php echo $list['pages']; ?> //总页数
                ,groups: 5 //连续显示分页数
                ,curr: <?php echo $list['curPage']; ?>
                ,skip: true
                ,jump: function(obj, first){
                    if(!first){
                        var url = window.location.href;
                        if(url.indexOf("?")==-1){
                            window.location.href = url+"?page="+obj.curr;
                        }else{
                            if(url.indexOf("page")==-1){
                                window.location.href = url+"&page="+obj.curr;
                            }else{
                                window.location.href = url.replace(/page=\d*/, 'page='+obj.curr)
                            }                                        
                        }
                    }                       
                }
            });
            var form = layui.form();
            //全选
            form.on('checkbox(allChoose)', function(data){
                var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]');
                child.each(function(index, item){
                    item.checked = data.elem.checked;
                });
                form.render('checkbox');
            });

        });

        function deleteAll(){
            var ids = [];
            $($("input[name='checkboxId[]']")).each(function(){
                if( this.checked ){
                    ids.push($(this).val());
                }
            });
            del(ids);
        }

        function del(id){
            layer.confirm('是否确定删除？', {
                btn: ['是','否'] //按钮
            }, function(){
                $.ajax({
                    type : 'post',
                    url : "<?php echo Url('deleteAll'); ?>",
                    data : {id:id},
                    dataType: 'json',
                    success: function(result){
                        if(result['status'] == 200){
                            if($.isArray(id)){
                                $(id).each(function(index,value){
                                    console.log(value);
                                    $("tr[data-id="+value+"]").remove();
                                });
                            }else{
                                $("tr[data-id="+id+"]").remove();
                            }
                            
                            layer.closeAll();
                        }else{
                            layer.msg(result.msg);
                        }
                    }
                });
            });
        }
    </script>
</div>

	</body>
</html>