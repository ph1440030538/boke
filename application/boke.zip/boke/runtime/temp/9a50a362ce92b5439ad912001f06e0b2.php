<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:70:"F:\PersonalWorks\boke\public/../application/admin\view\menu\index.html";i:1494691927;s:66:"F:\PersonalWorks\boke\public/../application/admin\view\layout.html";i:1493954682;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_header.html";i:1494647407;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
		<style type="text/css">
			body{background-color: #efefef;}
		    .boke-wrap{margin: 18px;padding: 15px;background-color: #fff;border-top: 3px solid #ddd;}
		    .boke-wrap .boke-search{padding: 10px 20px;background-color: #efefef;}
		    .boke-wrap .boke-search .layui-inline{margin-right: 18px;}
			.boke-wrap .boke-table tfoot{background-color: #efefef;}
		</style>
	</head>
<body>

 <div class="boke-wrap">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li class="layui-this">菜单列表</li>
            <li><a href="<?php echo Url('add'); ?>">添加菜单</a></li>
        </ul>
    </div>

    <div class="">
        <table class="layui-form layui-table" lay-skin="line">
            <colgroup>
                <col width="50">
                <col width="100">
                <col>
                <col width="100">
                <col width="200">
            </colgroup>

            <thead>
                <tr>
                    <th><input type="checkbox" name="" lay-skin="primary" lay-filter="allChoose"></th>
                    <td>id</td>
                    <th>分类名字</th>
                    <th>排序</th>
                    <th>操作</th>
                </tr> 
            </thead>
            <tbody>
                <?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr data-id="<?php echo $vo['id']; ?>">
                        <td><input type="checkbox" name="" lay-skin="primary"></td>
                        <td><?php echo $vo['id']; ?></td>
                        <td>
                            <?php echo $vo['name']; ?>
                        </td>
                        <td><input class="layui-input" type="text" value="<?php echo $vo['sort']; ?>"></td>
                        <td>
                            <a class="layui-btn layui-btn-mini" href="<?php echo Url('edit'); ?>?id=<?php echo $vo['id']; ?>">编辑</a>
                            <a class="layui-btn layui-btn-mini layui-btn-danger" href="javascript:;" onclick="del(<?php echo $vo['id']; ?>)" >删除</a>
                        </td>
                    </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
            <tfoot>
                <tr>
                    <td><button class="layui-btn layui-btn-small">删除</button></td>
                    <td colspan="4"></td>
                </tr>
            </tfoot>
        </table>
    </div>

    <script type="text/javascript">
        layui.use(['layer','form'], function(){
            var layer = layui.layer;
            var form = layui.form();
            //全选
            form.on('checkbox(allChoose)', function(data){
                var child = $(data.elem).parents('table').find('tbody input[type="checkbox"]');
                child.each(function(index, item){
                    item.checked = data.elem.checked;
                });
                form.render('checkbox');
            });

        });

        function deleteAll(){
            var ids = [];
            $($("input[name='checkboxId[]']")).each(function(){
                if( this.checked ){
                    ids.push($(this).val());
                }
            });
            del(ids);
        }

        function del(id){
            layer.confirm('是否确定删除？', {
                btn: ['是','否'] //按钮
            }, function(){
                $.ajax({
                    type : 'post',
                    url : "<?php echo Url('deleteAll'); ?>",
                    data : {id:id},
                    dataType: 'json',
                    success: function(result){
                        if(result['status'] == 200){
                            if($.isArray(id)){
                                $(id).each(function(index,value){
                                    console.log(value);
                                    $("tr[data-id="+value+"]").remove();
                                });
                            }else{
                                $("tr[data-id="+id+"]").remove();
                            }
                            
                            layer.closeAll();
                        }else{
                            layer.msg(result.msg);
                        }
                    }
                });
            });
        }
    </script>
</div>

	</body>
</html>