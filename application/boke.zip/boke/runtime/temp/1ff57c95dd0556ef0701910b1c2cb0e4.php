<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:70:"F:\PersonalWorks\boke\public/../application/admin\view\boke\index.html";i:1494461757;s:66:"F:\PersonalWorks\boke\public/../application/admin\view\layout.html";i:1493954682;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_header.html";i:1494253897;s:80:"F:\PersonalWorks\boke\public/../application/admin\view\public\layout_footer.html";i:1493954638;}*/ ?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>demo</title>
		<link rel="stylesheet" type="text/css" href="/static/layui/css/layui.css">
		<link rel="stylesheet" type="text/css" href="http://cdn.bootcss.com/font-awesome/4.6.0/css/font-awesome.min.css">
		<script type="text/javascript" src="/static/layui/layui.js"></script>
		<script type="text/javascript" src="http://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>
	</head>
<body>

 <style type="text/css">
    body{background-color: #fff;}
    .category-box{margin: 15px;}
    .layui-form{margin-bottom: 20px;background-color: #efefef;padding: 15px 0px;overflow: hidden;zoom: 1;}
    .page-title{position: relative;}
    .page-title h1{background-color: #fff;font-size: 20px;color:#393D49;font-weight: 300;padding: 10px 30px 10px 20px;border-bottom: 1px solid #dfdfdf;}
    .add-btn{float: right;margin-right: 20px;}
    .search-submit{margin-top: 20px;}
</style>
<div class="category-box">
    <div class="layui-tab">
        <ul class="layui-tab-title">
            <li class="layui-this">分类列表</li>
            <li><a href="<?php echo Url('admin/category/add'); ?>">添加分类</a></li>
        </ul>
    </div>

<!--     <form class="layui-form" action="">
        <div class="layui-inline">
            <label class="layui-form-label">名字</label>
            <div class="layui-input-block">
                <input type="text" name="title" required  lay-verify="required" placeholder="请输入名字" autocomplete="off" class="layui-input">
            </div>
        </div>

        <div class="layui-inline">
            <div class="layui-input-block">
                <button class="layui-btn" lay-submit lay-filter="formDemo">立即提交</button>
                <button type="reset" class="layui-btn layui-btn-primary">重置</button>
            </div>
        </div>
    </form> -->

    <div class="category-content">
        <table class="layui-table">
            <thead>
                <tr>
                    <th width="10">标题</th>
                    <th width="10">关键字</th>
                    <th width="10">描述</th>
                    <th width="10">内容</th>
                    <th width="10">文章来源</th>
                    <th width="10">article_tpl</th>
                    <th width="10">create_time</th>
                    <th width="10">update_time</th>
                    <th width="10">操作</th>
                </tr> 
            </thead>
            <tbody>
                <?php if(is_array($lists) || $lists instanceof \think\Collection || $lists instanceof \think\Paginator): $i = 0; $__LIST__ = $lists;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                    <tr data-id="<?php echo $vo['id']; ?>">
                        <td><?php echo $vo['title']; ?></td>
                        <td><?php echo $vo['create_time']; ?></td>
                        <td><?php echo $vo['create_time']; ?></td>
                        <td>
                            <a href="<?php echo Url('admin/category/edit'); ?>?id=<?php echo $vo['id']; ?>">编辑</a>/
                            <a href="javascript:;" onclick="del(<?php echo $vo['id']; ?>)" >删除</a>
                        </td>
                    </tr>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </tbody>
        </table>

        <div class="page">
            <div id="demo1"></div>
            <script>
                layui.use(['laypage', 'layer'], function(){
                    var laypage = layui.laypage
                    ,layer = layui.layer;
                    laypage({
                        cont: 'demo1'
                        ,pages: <?php echo $pages; ?> //总页数
                        ,groups: 5 //连续显示分页数
                        ,curr: <?php echo $curPage; ?>
                        ,skip: true
                        ,jump: function(obj, first){
                            if(!first){
                                window.location.href = "/admin/category/index?page="+obj.curr;
                            }                            
                        }
                    });
                });
            </script>


        </div>
    </div>

    <script type="text/javascript">
        function del(id){
            layer.confirm('是否确定删除？', {
                btn: ['是','否'] //按钮
            }, function(){
                $.ajax({
                    type : 'post',
                    url : "/admin/category/delete",
                    data : {id:id},
                    dataType: 'json',
                    success: function(result){
                        if(result['status'] == 200){
                            $("tr[data-id="+id+"]").remove();
                            layer.closeAll();
                        }else{
                            layer.msg(result.msg);
                        }
                    }
                });
            });
        }
    </script>
</div>

	</body>
</html>