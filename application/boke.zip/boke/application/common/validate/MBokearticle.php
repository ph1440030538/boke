<?php
namespace app\common\validate;
use think\Validate;

class MBokearticle extends Validate
{

}