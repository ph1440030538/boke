<?php
namespace app\common\validate;
use think\Validate;

class MBokedemo extends Validate
{

}