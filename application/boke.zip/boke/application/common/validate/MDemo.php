<?php
namespace app\common\validate;
use think\Validate;

class MDemo extends Validate
{

}