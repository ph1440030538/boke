<?php
namespace app\common\validate;
use think\Validate;

class Muser extends Validate
{
    protected $rule = [
        'username'  =>  'require|token',
        'password' =>  'require',
    ];
}