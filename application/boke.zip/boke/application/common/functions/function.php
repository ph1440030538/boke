<?php

	//列表模板
	function getListMoban(){
		
	}

	//文章模板
	function getPageMoban(){

	}