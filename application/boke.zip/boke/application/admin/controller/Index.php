<?php
namespace app\admin\controller;
use think\Controller;

class Index extends Controller
{
	public function index()
	{
		$this->redirect('common/login');
	}
}