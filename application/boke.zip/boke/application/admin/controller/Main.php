<?php
namespace app\admin\controller;

class Main extends Base
{
    public function index()
    {
    	$this->view->engine->layout(false);
        return view('index');
    }

    public function main(){
    	
    }

}
