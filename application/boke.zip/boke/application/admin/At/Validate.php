<?php
namespace app\common\validate;
use think\Validate;

class M【ControllerName】 extends Validate
{

}